import React, {
  Component
} from 'react';
import {Container, Icon, Text, ListItem, Spinner, Left, Body, CardItem, Content, Thumbnail} from 'native-base';

class ListRS extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
        <CardItem onPress={() => this.props.onSelected()}>
          <Body>
              <Text>{this.props.data.nama}</Text>
              <Text>{this.props.data.alamat}</Text>
          </Body>
      </CardItem>
    );
  }
}

module.exports = ListRS;
