import React, { Component } from 'react';
import { View, Text, BackHandler } from 'react-native';
import NavigationExperimental from 'react-native-deprecated-custom-components';
import Splash from '../src/Splash';

export default class root extends Component {

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      if (this.appNav && this.appNav.getCurrentRoutes().length > 1) {
        this.appNav.pop();
        return true;
      }
        return false;
    });
  }

  render() {
    return (
      <NavigationExperimental.Navigator
        renderScene={this.renderScene}
        initialRoute={{component: Splash}}
        ref={(nav) => { this.appNav = nav; }}
       />
      );
    }

    renderScene(route, navigator) {
      return <route.component navigator={navigator} {...route.passProps} />
    }
}
