import React, {Component} from 'react';
import {View, Text, StyleSheet, Image} from 'react-native';

export default class About extends Component {
    render() {
        return (
            <View style={styles.container}>
              <View style={styles.logoContainer}>
                <Image style={styles.image} source={require('../assets/ic_launcher.png')} />
                <Text style={{fontSize: 30, textAlign: 'center', margin: 10}}>FindHospital</Text>
                <Text style={styles.title}>Jika ada bug atau error silahkan hubungi e-mail Agung Hidayat di 157006049@student.unsil.ac.id</Text>
              </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    logoContainer: {
        flexGrow: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    image: {
        width: 150,
        height: 150,
        marginBottom: 20
    },
    title: {
       fontSize: 20,
        textAlign: 'center',
        margin: 10,
    }
})
