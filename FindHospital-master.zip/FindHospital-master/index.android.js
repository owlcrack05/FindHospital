/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
import {
  AppRegistry,
} from 'react-native';
import root from './src/root';

AppRegistry.registerComponent('FindHospital', () => root);
